Welcome to Interactive Physics!

This on-line document contains the following information.

1. Changes to Your System Made by Interactive Physics Setup
2. Uninstalling Interactive Physics
3. Copyright information

------------------------------------------------------------
1. Changes to Your System Made by Interactive Physics Setup
------------------------------------------------------------

This section describes the changes made to your system by
Interactive Physics Setup.

1.1. Interactive Physics (Application)

Interactive Physics Setup copies the files in the directory 
specified at the installation time (the default directory is 
\Interactive Physics).

1.2. Shared Libraries

The following files are copied to or updated in WINDOWS\SYSTEM
(for Windows 95) or WINNT\SYSTEM32 (for Windows NT):
(Microsoft Foundation Classes Libraries)

MFC42.DLL
MSVCRT.DLL
MSVCP50.DLL
MSVCIRT.DLL

(NOTE: The pathname of the Windows system directory may be different
on your system.)

-------------------------------------------------------------
2. Uninstalling Interactive Physics
-------------------------------------------------------------

To remove the components installed by Interactive Physics 
Setup, simply open the item "Add/Remove Program" in the Control Panel, 
and look for the item titled "Interactive Physics"

The Uninstaller removes the Interactive Physics files and 
then attempts to delete its directory.  However, since the uninstaller 
does not remove any files created AFTER the Interactive Physics 
installation, the files you created on your own (such as Interactive 
Physics document) will not be deleted.  Therefore, the uninstaller will 
fail to delete the Interactive Physics directory if it contains any 
files you created.

In addition, the Uninstaller will NOT delete the shared libraries (such 
as MFC42.DLL) installed by the Setup, if other programs that are
installed after Interactive Physics depend on these libraries.
Interactive Physics Uninstaller will ask you whether it can 
delete these files ONLY IF the reference count of these DLLs are 
decremented to zero (i.e., when your system Registry shows that 
Interactive Physics is the only application that relies on 
these libraries).

--------------------------------------------------------------------
3. Copyright Information
--------------------------------------------------------------------

Copyright 2000 by MSC.Working Knowledge
Portions 1992-1998 Summit Software
Portions of guide by guideWorks, LLC

All rights reserved. No part of this product may be reproduced,
transmitted or used in any form or by any means except as provided
in the end-user license agreement found in the installation
program.

